package com.ram.springboot.service;


import com.ram.springboot.bean.Users;

public interface UsersService {
	void saveUsers(Users user);
	Users loginCheck(String userName,String password);
}
