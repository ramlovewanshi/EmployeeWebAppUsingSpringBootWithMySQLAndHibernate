package com.ram.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ram.springboot.bean.Users;

public interface UsersRepository extends JpaRepository<Users, Long> {
	  @Query("SELECT u FROM Users u WHERE u.username = :username and u.password=:password")
	  public Users getUsersByUsername(@Param("username") String username,@Param("password") String password);
	  
}
