package com.ram.springboot.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;


import com.ram.springboot.bean.Employee;
import com.ram.springboot.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	// display list of employees
		@RequestMapping("/index")
		public String openinddex(Model model) {
			List<Employee> al=null;
			try {
			 al=employeeService.getAllEmployees();
			}catch(Exception e) {
				
					return "redirect:openf1";
				
			}
			System.out.println("Hii....Index  Method is called "+al);
			model.addAttribute("emps", al);
			return "index";	
		}
	@GetMapping("/openf1")
	public String showNewEmployeeForm(Model model) {
		// create model attribute to bind form data
		Employee employee = new Employee();
		model.addAttribute("command", employee);
		return "new_employee";
	}
	@RequestMapping("/save")
	public String saveEmployee(@ModelAttribute("command") Employee employee) {
		// save employee to database
		employeeService.saveEmployee(employee);
		return "redirect:/index";
	}
	
	@RequestMapping("/update")
	public String updateEmployee(@ModelAttribute("command") Employee employee) {
		// save employee to database
		employeeService.saveEmployee(employee);
		return "redirect:/index";
	}
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable ( value = "id") long id, Model model) {
		
		// get employee from the service
		Employee employee = employeeService.getEmployeeById(id);
		
		// set employee as a model attribute to pre-populate the form
		model.addAttribute("command", employee);
		return "update_employee";
	}
	
	@GetMapping("/deleteEmployee/{id}")
	public String deleteEmployee(@PathVariable ( value = "id") Long id) {
		
		// call delete employee method 
		this.employeeService.deleteEmployeeById(id);
		return "redirect:/index";
	}
	
	
	}

