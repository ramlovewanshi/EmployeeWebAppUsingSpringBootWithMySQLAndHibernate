package com.ram.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ram.springboot.bean.Users;

import com.ram.springboot.repository.UsersRepository;
@Service
public class UsersServiceImpl implements UsersService {

	@Autowired
	private UsersRepository usersRepository;

	@Override
	public void saveUsers(Users user) {
		this.usersRepository.save(user);
		
	}

	@Override
	public Users loginCheck(String userName, String password) {
		// TODO Auto-generated method stub
		return this.usersRepository.getUsersByUsername(userName, password);
	}

}
