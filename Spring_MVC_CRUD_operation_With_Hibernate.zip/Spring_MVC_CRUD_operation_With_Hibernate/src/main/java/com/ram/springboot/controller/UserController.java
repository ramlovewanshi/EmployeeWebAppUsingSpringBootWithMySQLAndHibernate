package com.ram.springboot.controller;

import java.io.IOException;
import java.io.PrintWriter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ram.springboot.bean.Users;
import com.ram.springboot.service.UsersService;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	@Autowired
	private UsersService usersService;
	@GetMapping("/register")
	public String showRegisterationForm(Model model) {
		// create model attribute to bind form data
		Users user = new Users();
		model.addAttribute("command", user);
		return "register";
	}
	
	
	@GetMapping("/login")
	public String showLoginForm(Model model) {
		// create model attribute to bind form data
		Users user = new Users();
		model.addAttribute("command", user);
		return "login";
	}
	
	@RequestMapping("/userlogin")
	public String loginUser(@ModelAttribute("command") Users user,HttpServletRequest req,HttpServletResponse response) {
		// save user to database
	Users u=usersService.loginCheck(user.getUsername(), user.getPassword());
	HttpSession s=req.getSession();
	if(u!=null) {
			
			s.setAttribute("un", u.getName());
			return "redirect:/index";
		}else {
		    
			
			return "redirect:/login";
		}
		
	}
	
	
	@RequestMapping("/usersave")
	public String saveUser(@ModelAttribute("command") Users user) {
		// save user to database
		usersService.saveUsers(user);
		return "redirect:/login";
	}
	
	
}
